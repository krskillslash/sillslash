export interface ImageType {
    src: string;
    caption: string;
}
