export interface HelpLink {
    icon: string;
    title: string;
    links: string[];
}
