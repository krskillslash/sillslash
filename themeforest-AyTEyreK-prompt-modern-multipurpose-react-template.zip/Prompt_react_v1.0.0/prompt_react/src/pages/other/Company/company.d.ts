export interface TeamMember {
    avatar: string;
    name: string;
    designation: string;
}
