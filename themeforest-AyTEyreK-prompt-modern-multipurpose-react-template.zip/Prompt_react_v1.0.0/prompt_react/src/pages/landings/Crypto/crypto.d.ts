export interface Coin {
    icon: string;
    name: string;
}

export interface Feature {
    icon: string;
    title: string;
    description: string;
}
