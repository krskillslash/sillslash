export interface Feature {
    variant: string;
    icon: string;
    title: string;
    description: string;
}
