export interface Feature {
    deviceIcon: string;
    deviceName: string;
}
